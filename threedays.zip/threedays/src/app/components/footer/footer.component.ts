import { Component, OnInit, OnChanges, OnDestroy, SimpleChanges} from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit, OnChanges, OnDestroy {

  txt = '';
  changes: SimpleChanges | any;

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    this.changes = changes;
    console.log('changes : ' + this.changes);
  }

  ngOnInit(): void {
  }

  ngOnDestroy(): void {
    console.log('App Close');
  }

}
