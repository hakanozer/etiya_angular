import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { SeoService } from '../../services/seo.service';
import * as $ from 'jquery';
import { HttpClient } from '@angular/common/http';
import { CityModel } from '../../models/model';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, AfterViewInit {

  constructor(
    private seo: SeoService,
    private http: HttpClient,
    private city: CityModel
    ) { }

  cityData = this.city.cities;
  category = [];
  name = 'Deneme';
  htmldata = '<h1>Hello Angular!</h1>';
  @ViewChild('txtName') txtNameRef: ElementRef | any;

  ngOnInit(): void {
    this.seo.updateTitle('App - Home');
    this.seo.updateMeta('description', 'Home description');

    const url = 'http://jsonbulut.com/json/companyCategory.php?ref=5380f5dbcc3b1021f93ab24c3a1aac24';
    this.http.get(url).subscribe(res => {
      const st = JSON.stringify(res);
      this.category = JSON.parse(st).Kategoriler[0].Categories;
      console.log(this.category);
    });

    this.fncOne().then( res => {
      this.fncTwo().then( res => {
        this.fncThree().then( res => {
          console.log('All Functions Finish!');
        });
      });
    });

    this.cityData.forEach( (item, index) => {
      console.log(item.id + ' ' + item.name);
    });

  }

  fncBtnSend(): void {

    const h = $('#txtNameID').outerHeight();
    if (this.name === '') {
      console.log('h : ' + h);
      $('#txtNameID').animate({
        height : 0,
      }, 200, () => {
        $('#txtNameID').animate({ height: h }, 100);
      });
      this.txtNameRef.nativeElement.focus();
    }


  }

  ngAfterViewInit(): void {
    this.txtNameRef.nativeElement.focus();
  }


  fncOne() {
     return new Promise( (resolve, reject) => {
      console.log('fncOne Call -1');
      resolve();
    });
  }

  fncTwo() {
    return new Promise( (resolve, reject) => {
      setTimeout(() => {
        console.log('fncTwo Call -2');
        resolve();
      }, 2000);
    });

  }

  fncThree() {
    return new Promise( (resolve, reject) => {
      console.log('fncThree Call -3');
      resolve();
    });
  }


}
