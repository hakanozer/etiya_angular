import { Component, OnInit } from '@angular/core';
import { SeoService } from '../../services/seo.service';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  constructor( private seo: SeoService )
  {
    console.log('AboutComponent call');
  }

  ngOnInit(): void {
    this.seo.updateTitle('App - About');
    this.seo.updateMeta('description', 'About description');
  }

}
