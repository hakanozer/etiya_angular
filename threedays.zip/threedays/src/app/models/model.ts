import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CityModel {

  cities = [
    { id: 27, name: 'Gaziantep' },
    { id: 34, name: 'İstanbul' },
    { id: 6, name: 'Ankara' },
    { id: 1, name: 'Adana' }
  ];

}
