import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  title = 'threedays';

  ngOnInit(): void {
    // window.console.log = function() {}; // all console fnc Off
    const ut: any = null;
    ut.sum(10, 20);

  }


}
