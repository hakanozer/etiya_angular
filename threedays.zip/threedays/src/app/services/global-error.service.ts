import { Injectable, ErrorHandler } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GlobalErrorService implements ErrorHandler {

  constructor() { }

  handleError(error: any): void {
    console.error('Error Create');
    console.log(error.url);
    console.log(error.status);
    console.log(error.name);
    console.log(error.message);
  }
}
