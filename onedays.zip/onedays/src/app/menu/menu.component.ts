import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  userName = '';
  constructor( private routerNavigate: Router ) { }

  ngOnInit(): void {
    const session = sessionStorage.getItem('user');
    if (session == null) {
      this.routerNavigate.navigate(['home']);
    }else {
      this.userName = atob(atob(session));
    }
  }

  fncLogout(): void {
    const answer = confirm('Are you sure!');
    if (answer) {
      sessionStorage.removeItem('user');
      this.routerNavigate.navigate(['home']);
    }
  }


}
