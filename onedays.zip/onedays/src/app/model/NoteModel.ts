export interface NoteModel {
  title: string;
  detail: string;
  date: string;
}
