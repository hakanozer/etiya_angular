import { HttpClient } from '@angular/common/http';

  const params = {
    sources: 'google-news',
    apiKey: '38a9e086f10b445faabb4461c4aa71f8'
  };

  const url = 'http://newsapi.org/v2/top-headlines?sources=google-news-in&apiKey=38a9e086f10b445faabb4461c4aa71f8';

  export fncNewsService(http) {
    return http.get(url);
  }


