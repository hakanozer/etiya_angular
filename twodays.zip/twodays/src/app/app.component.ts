import { JSONData, Article } from './../model/JSONData';
import { ThrowStmt } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  newsArr: Article[] = [];
  title = 'twodays';
  greenColor = 'green';
  redColor = 'red';
  focusStatus = '';
  dataFocus = '';

  constructor( private http: HttpClient ) {}

  ngOnInit(): void {

  }

  funcSendBtn(): void {
    const params = {
      sources: 'google-news',
      apiKey: '38a9e086f10b445faabb4461c4aa71f8'
    };
    const url = 'http://newsapi.org/v2/top-headlines';
    this.http.get(url, {params}).subscribe( items => {
      const jsData: JSONData | any = items;
      this.newsArr = jsData.articles;
    })
  }



  async fncSample() {
    return await "";
  }


}
