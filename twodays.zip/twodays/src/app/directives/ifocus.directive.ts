import { Directive, Input, ElementRef, OnInit } from '@angular/core';

@Directive({
  selector: '[appIfocus]'
})
export class IfocusDirective implements OnInit {

  @Input() appIfocus: string | any;

  constructor( private ref: ElementRef ) { }

  ngOnInit(): void {
    if( this.appIfocus === 'focus' ) {
      this.ref.nativeElement.focus();
    }
  }

}
