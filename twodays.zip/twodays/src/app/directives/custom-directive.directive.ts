import { Directive, ElementRef, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[colors]'
})
export class CustomDirectiveDirective implements OnInit {

  @Input() colors: string | any;

  constructor( private ref: ElementRef ) { }

  ngOnInit(): void {
    this.ref.nativeElement.style.backgroundColor = this.colors;
  }

}
