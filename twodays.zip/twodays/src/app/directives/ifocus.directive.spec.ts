import { IfocusDirective } from './ifocus.directive';

describe('IfocusDirective', () => {
  it('should create an instance', () => {
    const directive = new IfocusDirective();
    expect(directive).toBeTruthy();
  });
});
