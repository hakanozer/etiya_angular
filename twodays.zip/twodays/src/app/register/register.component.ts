import { Util } from './../../utils/Util';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegisterData } from '../../model/RegisterData';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  frmRegister: any;
  userName = '';
  userSurname = '';
  userPhone = '';
  userMail = '';
  userPass = '';

  constructor( private util: Util, private formBuilder: FormBuilder ) { }

  ngOnInit(): void {

  }

  fncUserRegister() {
    if (this.userName === '') {
      alert('Items not empty!');
    }else {
      const params = {
        userName: this.userName,
        userSurname: this.userSurname,
        userPhone: this.userPhone,
        userMail: this.userMail,
        userPass: this.userPass
      }
      this.util.userRegister(params).subscribe(res => {
            const dt: RegisterData | any = res;
            if ( dt.user[0].durum ) {
              console.log( JSON.stringify(dt) );
            }else {
              alert('Register Fail');
            }
      });
    }

  }

}
